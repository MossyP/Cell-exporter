bl_info = {
    "name": "Cell Exporter",
    "author": "Mossy",
    "version": (1, 0, 3),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Cell Exporter",
    "description": "Export collections as separate cellfolders for After Effects",
    "category": "Render",
}

import bpy
import os
from bpy.types import Panel, Operator, PropertyGroup, UIList
from bpy.props import (
    StringProperty, BoolProperty, EnumProperty,
    CollectionProperty, IntProperty, PointerProperty
)


class CELLEXPORTER_CellItem(PropertyGroup):
    cell_name: StringProperty(name="Cell Name", default="Cell_A")
    collection: PointerProperty(name="Collection", type=bpy.types.Collection)
    enabled: BoolProperty(name="Enabled", default=True)


class CELLEXPORTER_SceneProperties(PropertyGroup):
    output_base_path: StringProperty(
        name="Output Base Path",
        default="//cell_export/",
        subtype='DIR_PATH'
    )
    output_format: EnumProperty(
        name="Format",
        items=[
            ('PNG', "PNG", "PNG sequence"),
            ('OPEN_EXR_MULTILAYER', "EXR Multilayer", "EXR multilayer"),
            ('OPEN_EXR', "EXR Single", "EXR single"),
        ],
        default='PNG'
    )
    png_depth: EnumProperty(
        name="Bit Depth",
        items=[('8', "8bit", ""), ('16', "16bit", "")],
        default='8'
    )
    frame_padding: IntProperty(name="Frame Padding", default=4, min=1, max=8)
    cells: CollectionProperty(type=CELLEXPORTER_CellItem)
    active_cell_index: IntProperty(default=0)
    generate_jsx: BoolProperty(name="Generate AE Script (.jsx)", default=True)
    ae_comp_width:  IntProperty(name="W", default=1920, min=1)
    ae_comp_height: IntProperty(name="H", default=1080, min=1)
    ae_frame_rate: EnumProperty(
        name="FPS",
        items=[('24','24',''),('25','25',''),('30','30',''),('60','60','')],
        default='24'
    )


class CELLEXPORTER_UL_CellList(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        row = layout.row(align=True)
        row.prop(item, "enabled", text="")
        row.prop(item, "cell_name", text="", emboss=False)
        row.label(text="→")
        row.prop(item, "collection", text="")


class CELLEXPORTER_OT_AddCell(Operator):
    bl_idname = "cell_exporter.add_cell"
    bl_label = "Add Cell"
    def execute(self, context):
        props = context.scene.cell_exporter
        item = props.cells.add()
        item.cell_name = f"Cell_{chr(64 + len(props.cells))}"
        props.active_cell_index = len(props.cells) - 1
        return {'FINISHED'}


class CELLEXPORTER_OT_RemoveCell(Operator):
    bl_idname = "cell_exporter.remove_cell"
    bl_label = "Remove Cell"
    def execute(self, context):
        props = context.scene.cell_exporter
        if props.cells:
            props.cells.remove(props.active_cell_index)
            props.active_cell_index = max(0, props.active_cell_index - 1)
        return {'FINISHED'}


class CELLEXPORTER_OT_MoveCell(Operator):
    bl_idname = "cell_exporter.move_cell"
    bl_label = "Move Cell"
    direction: EnumProperty(items=[('UP','Up',''),('DOWN','Down','')])
    def execute(self, context):
        props = context.scene.cell_exporter
        idx = props.active_cell_index
        if self.direction == 'UP' and idx > 0:
            props.cells.move(idx, idx - 1)
            props.active_cell_index -= 1
        elif self.direction == 'DOWN' and idx < len(props.cells) - 1:
            props.cells.move(idx, idx + 1)
            props.active_cell_index += 1
        return {'FINISHED'}


class CELLEXPORTER_OT_Export(Operator):
    bl_idname = "cell_exporter.export"
    bl_label = "Export All Cells"

    def execute(self, context):
        scene = context.scene
        props = scene.cell_exporter

        active_cells = [c for c in props.cells if c.enabled and c.collection]
        if not active_cells:
            self.report({'WARNING'}, "No enabled Cells with collections assigned.")
            return {'CANCELLED'}

        base_path = bpy.path.abspath(props.output_base_path)
        os.makedirs(base_path, exist_ok=True)

        # Backup
        orig_filepath      = scene.render.filepath
        orig_format        = scene.render.image_settings.file_format
        orig_color_mode    = scene.render.image_settings.color_mode
        orig_color_depth   = scene.render.image_settings.color_depth
        orig_transparent   = scene.render.film_transparent

        for cell in active_cells:
            cell_path = os.path.join(base_path, cell.cell_name)
            os.makedirs(cell_path, exist_ok=True)

            scene.render.filepath = os.path.join(cell_path, "#" * props.frame_padding)
            scene.render.image_settings.file_format = props.output_format
            scene.render.film_transparent = True  # BGを透明化

            if props.output_format == 'PNG':
                scene.render.image_settings.color_mode  = 'RGBA'
                scene.render.image_settings.color_depth = props.png_depth

            # 全オブジェクトのhide_render状態を保存して一旦全部非表示
            saved = {}
            for obj in scene.objects:
                saved[obj.name] = obj.hide_render
                obj.hide_render = True

            # 対象コレクションのオブジェクトだけ表示
            target = set()
            self._collect_objects(cell.collection, target)
            for obj in target:
                obj.hide_render = False

            # ライト,カメラは常に表示
            for obj in scene.objects:
                if obj.type in {'LIGHT', 'CAMERA', 'LIGHT_PROBE'}:
                    obj.hide_render = False

            self.report({'INFO'}, f"Cell: {cell.cell_name} | Objects: {len(target)}")
            bpy.ops.render.render(animation=True)

            # hide_render を元に戻す
            for obj in scene.objects:
                if obj.name in saved:
                    obj.hide_render = saved[obj.name]

        # レンダー設定を戻す
        scene.render.filepath                   = orig_filepath
        scene.render.image_settings.file_format = orig_format
        scene.render.image_settings.color_mode  = orig_color_mode
        scene.render.image_settings.color_depth = orig_color_depth
        scene.render.film_transparent           = orig_transparent

        if props.generate_jsx:
            jsx_path = os.path.join(base_path, "import_cells.jsx")
            self._write_jsx(props, active_cells, base_path, jsx_path, scene)

        self.report({'INFO'}, f"Done! → {base_path}")
        return {'FINISHED'}

    def _collect_objects(self, collection, result: set):
        for obj in collection.objects:
            result.add(obj)
        for child in collection.children:
            self._collect_objects(child, result)

    def _write_jsx(self, props, active_cells, base_path, jsx_path, scene):
        fps         = int(props.ae_frame_rate)
        frame_count = scene.frame_end - scene.frame_start + 1
        duration    = float(frame_count) / float(fps)
        pad         = int(props.frame_padding)
        ext         = 'exr' if 'EXR' in props.output_format else 'png'
        w           = int(props.ae_comp_width)
        h           = int(props.ae_comp_height)

        jsx = []
        jsx.append('// Cell Exporter - Auto-generated AE script')
        jsx.append('(function() {')
        jsx.append('  var proj = app.project;')
        jsx.append('  var w = %d;' % w)
        jsx.append('  var h = %d;' % h)
        jsx.append('  var dur = %.4f;' % duration)
        jsx.append('  var fps = %d;' % fps)
        jsx.append('  var comp = proj.items.addComp("CellExport_Comp", w, h, 1.0, dur, fps);')
        jsx.append('  var layers = [];')
        jsx.append('')

        for cell in active_cells:
            folder     = os.path.join(base_path, cell.cell_name).replace("\\", "/")
            first_file = str(scene.frame_start).zfill(pad) + "." + ext
            path       = (folder + "/" + first_file).replace("\\", "/")
            n          = cell.cell_name
            jsx.append('  // %s' % n)
            jsx.append('  try {')
            jsx.append('    var seqFile = new File("%s");' % path)
            jsx.append('    var io = new ImportOptions(seqFile);')
            jsx.append('    io.sequence = true;')
            jsx.append('    io.forceAlphabetical = true;')
            jsx.append('    var ftg = proj.importFile(io);')
            jsx.append('    ftg.name = "%s";' % n)
            jsx.append('    ftg.mainSource.conformFrameRate = %d;' % fps)
            jsx.append('    layers.push({footage: ftg, name: "%s"});' % n)
            jsx.append('  } catch(e) {')
            jsx.append('    alert("Import failed: %s - " + e.toString());' % n)
            jsx.append('  }')
            jsx.append('')

        jsx.append('  // Add layers: Cell_A on top (reverse order)')
        jsx.append('  for (var i = layers.length - 1; i >= 0; i--) {')
        jsx.append('    var lyr = comp.layers.add(layers[i].footage);')
        jsx.append('    lyr.name = layers[i].name;')
        jsx.append('    lyr.startTime = 0;')
        jsx.append('  }')
        jsx.append('  comp.openInViewer();')
        jsx.append('  alert("Import complete! " + layers.length + " layers");')
        jsx.append('})();')

        with open(jsx_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(jsx))


class CELLEXPORTER_PT_MainPanel(Panel):
    bl_label       = "Cell Exporter for AE"
    bl_idname      = "CELLEXPORTER_PT_main"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "Cell Exporter"

    def draw(self, context):
        layout = self.layout
        props  = context.scene.cell_exporter
        scene  = context.scene

        box = layout.box()
        box.label(text="Output", icon='EXPORT')
        box.prop(props, "output_base_path")
        row = box.row(align=True)
        row.prop(props, "output_format")
        if props.output_format == 'PNG':
            row.prop(props, "png_depth", expand=True)
        box.prop(props, "frame_padding")

        layout.separator()

        box = layout.box()
        box.label(text="Cells", icon='COLLECTION_COLOR_01')
        row = box.row()
        col = row.column()
        col.template_list("CELLEXPORTER_UL_CellList", "", props, "cells", props, "active_cell_index", rows=4)
        col2 = row.column(align=True)
        col2.operator("cell_exporter.add_cell",    icon='ADD',    text="")
        col2.operator("cell_exporter.remove_cell", icon='REMOVE', text="")
        col2.separator()
        op = col2.operator("cell_exporter.move_cell", icon='TRIA_UP',   text=""); op.direction = 'UP'
        op = col2.operator("cell_exporter.move_cell", icon='TRIA_DOWN', text=""); op.direction = 'DOWN'

        layout.separator()

        box = layout.box()
        box.prop(props, "generate_jsx", icon='FILE_SCRIPT')
        if props.generate_jsx:
            row = box.row(align=True)
            row.prop(props, "ae_comp_width")
            row.prop(props, "ae_comp_height")
            box.prop(props, "ae_frame_rate")

        layout.separator()

        box = layout.box()
        box.label(text=f"Frame Range: {scene.frame_start} – {scene.frame_end}", icon='TIME')

        layout.separator()

        enabled_count = sum(1 for c in props.cells if c.enabled and c.collection)
        row = layout.row()
        row.scale_y = 1.8
        row.operator("cell_exporter.export",
            text=f"Export {enabled_count} Cell{'s' if enabled_count != 1 else ''}",
            icon='RENDER_ANIMATION')


classes = [
    CELLEXPORTER_CellItem,
    CELLEXPORTER_SceneProperties,
    CELLEXPORTER_UL_CellList,
    CELLEXPORTER_OT_AddCell,
    CELLEXPORTER_OT_RemoveCell,
    CELLEXPORTER_OT_MoveCell,
    CELLEXPORTER_OT_Export,
    CELLEXPORTER_PT_MainPanel,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.cell_exporter = PointerProperty(type=CELLEXPORTER_SceneProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.cell_exporter

if __name__ == "__main__":
    register()
